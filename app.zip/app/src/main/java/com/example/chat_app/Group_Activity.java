package com.example.chat_app;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Group_Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_group_);
    }
}